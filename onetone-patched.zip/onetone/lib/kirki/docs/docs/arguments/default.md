---
layout: default
title: default
published: true
mainMaxWidth: 50rem;
---

You can use the `default` argument to define a default value for your controls.

You should **always** use a default value.

Some controls use arrays while others use strings. Please consult the control type's documentation for details and examples.
