<form role="search" class="search-form" action="<?php echo esc_url(home_url('/'));?>">
 <div>
  <label class="sr-only"><?php _e("Search for","onetone");?>:</label>
   <input type="text" name="s" id="s" value="" placeholder="<?php _e("Search...","onetone");?>">
   <input type="submit" value="">
  </div>
 </form>