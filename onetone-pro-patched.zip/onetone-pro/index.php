<?php
/**
* The main template file.
*
*/
 ?>
<?php

$is_not_home = ( 'page' == get_option( 'show_on_front' ) && ( '' != get_option( 'page_for_posts' ) ) && $wp_query->get_queried_object_id() == get_option( 'page_for_posts' ) );

if ( $is_not_home ) :

$left_sidebar   = onetone_option('left_sidebar_blog_archive','');
$right_sidebar  = onetone_option('right_sidebar_blog_archive','');
$aside          = 'no-aside';
if( $left_sidebar !='' )
$aside          = 'left-aside';
if( $right_sidebar !='' )
$aside          = 'right-aside';
if(  $left_sidebar !='' && $right_sidebar !='' )
$aside          = 'both-aside';


$detect                    = new Mobile_Detect;
$enable_page_title_bar     = onetone_option('enable_page_title_bar');
$display_title_bar_title   = onetone_option('display_title_bar_title',1 );
$display_breadcrumb        = esc_attr(onetone_option('display_breadcrumb','yes'));
$breadcrumbs_on_mobile     = esc_attr(onetone_option('breadcrumbs_on_mobile_devices','yes'));
$breadcrumb_menu_prefix    = esc_attr(onetone_option('breadcrumb_menu_prefix',''));
$breadcrumb_menu_separator = esc_attr(onetone_option('breadcrumb_menu_separator','/'));

?>

<?php if( $enable_page_title_bar == 'yes' || $enable_page_title_bar == '1'  ):?>
  
  <section class="page-title-bar title-left no-subtitle">
    <div class="container">
    <?php if($display_title_bar_title == 1 ):?>
      <hgroup class="page-title">
        <h1>
        <?php 
		 $blog_title = get_the_title( get_option('page_for_posts', true) );
		 echo $blog_title;
		?>
        </h1>
      </hgroup>
      <?php endif;?>
      <?php if( $display_breadcrumb == 'yes' && !$detect->isMobile() ):?>
      <?php onetone_get_breadcrumb(array("before"=>"<div class=''>".$breadcrumb_menu_prefix,"after"=>"</div>","show_browse"=>false,"separator"=>$breadcrumb_menu_separator,'container'=>'div'));?>
       <?php endif;?>
       
       <?php if( $breadcrumbs_on_mobile == 'yes' && $detect->isMobile()):?>
      <?php onetone_get_breadcrumb(array("before"=>"<div class=''>".$breadcrumb_menu_prefix,"after"=>"</div>","show_browse"=>false,"separator"=>$breadcrumb_menu_separator,'container'=>'div'));?>
       <?php endif;?>
       
      <div class="clearfix"></div>
    </div>
  </section>
 
  <?php endif;?>     
        
<div class="post-wrap">
            <div class="container">
                <div class="post-inner row <?php echo $aside; ?>">
                    <div class="col-main">
                        <section class="post-main" role="main" id="content">                        
                            <article class="page type-page" role="article">
                            <?php if (have_posts()) :?>
                                <!--blog list begin-->
                                <div class="blog-list-wrap">
                                
                                <?php while ( have_posts() ) : the_post();?>
                                <?php get_template_part("content",get_post_format()); ?>
                                <?php endwhile;?>
                                </div>
                                <?php endif;?>
                                <!--blog list end-->
                                <!--list pagination begin-->
                                <nav class="post-list-pagination" role="navigation">
                                    <?php if(function_exists("onetone_native_pagenavi")){onetone_native_pagenavi("echo",$wp_query);}?>
                                </nav>
                                <!--list pagination end-->
                            </article>
                            <div class="post-attributes"></div>
                        </section>
                    </div>
                    <?php if( $left_sidebar !='' ):?>
                    <div class="col-aside-left">
                        <aside class="blog-side left text-left">
                            <div class="widget-area">
                                <?php get_sidebar('archiveleft');?> 
                            </div>
                        </aside>
                    </div>
                    <?php endif; ?>
                    <?php if( $right_sidebar !='' ):?>
                    <div class="col-aside-right">
                       <?php get_sidebar('archiveright');?>
                    </div>
                    <?php endif; ?>
                    
                </div>
            </div>  
        </div>
<?php get_footer();?>
<?php 
  else: 
?>
<?php get_template_part('template','home');?>
<?php endif;?>
