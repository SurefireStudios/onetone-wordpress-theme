Onetone Theme
================

## Copyrights for Resources used in this theme.

--------------------------------------------------------------------------------------------

Onetone is a one-page responsive business theme based on HTML5/CSS3. All required information are displayed on a single page with clear order according to users�� preferences. The basic sections designed for business purpose have already been built for you. There��s also an extensive admin panel where unlimited sections can be easily added. Multiple options are available if you prefer to do some adjustments,such as changing background, video background, Font Awesome Icons, uploading logo and favicon,adding custom CSS and so on.


	For any help you can mail me at support[at]mageewp.com


/**********************************************************/

