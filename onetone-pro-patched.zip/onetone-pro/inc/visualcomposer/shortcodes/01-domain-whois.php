<?php
vc_map( array(
        "name" =>"Domain Whois",
        "base" => "wpdomainwhois",
        "description" => "Display Domain Whois",
		"show_settings_on_create" => false,
        "category" => esc_html__( 'Webnus Shortcodes', 'easyweb' ),
        "icon" => "wpdomainwhois",
    ) );
?>