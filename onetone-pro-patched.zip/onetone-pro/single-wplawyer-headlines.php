<?php
/**
* WP Post Template: PTD Headlines
*/

get_header(); ?>

<div class="container">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
        
				<!-- Start the Loop -->
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				
				    <?php the_content(); ?>

		</main><!-- #main -->
	</div><!-- #primary -->
	<?php get_sidebar(); ?>
</div><!-- .wrap -->

		<?php endwhile; else: ?>

<p>Sorry, this attorney appears to no longer exist.</p>

		<?php endif; ?>

<?php get_footer(); ?>