<?php

define( 'ONETONE_THEME_BASE_URL', get_template_directory_uri());
define( 'ONETONE_OPTIONS_FRAMEWORK', get_template_directory().'/admin/' ); 
define( 'ONETONE_OPTIONS_FRAMEWORK_URI',  ONETONE_THEME_BASE_URL. '/admin/'); 
define( 'ONETONE_OPTIONS_PREFIXED' ,'onetone_' );


define( 'OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/admin/' );

/**
 * Theme Functions
 **/
 
load_template( trailingslashit( get_template_directory() ) . 'includes/theme-functions.php' );

/**
 * Required: include options framework.
 **/
load_template( trailingslashit( get_template_directory() ) . 'admin/options-framework.php' );

global $onetone_options_saved;
$onetone_options_saved = false;
$option_name           = onetone_option_name();

if ( get_option($option_name) ) {
	$onetone_options_saved = true;
}

/**
 * google fonts
 **/
 
load_template( trailingslashit( get_template_directory() ) . 'includes/google-fonts.php' );


require_once get_template_directory() . '/includes/admin-options.php';

/**
 * Mobile Detect Library
 **/
 if(!class_exists("Mobile_Detect")){
   load_template( trailingslashit( get_template_directory() ) . 'includes/Mobile_Detect.php' );
 }
/**
 * Theme setup
 **/
 
load_template( trailingslashit( get_template_directory() ) . 'includes/theme-setup.php' );




/**
 * Onetone Shortcodes
 **/
 
load_template( trailingslashit( get_template_directory() ) . 'includes/shortcodes.php' );


/**
 * Theme breadcrumb
 */
load_template( trailingslashit( get_template_directory() ) . 'includes/breadcrumb-trail.php');

/**
 * Theme widget
 **/
 
load_template( trailingslashit( get_template_directory() ) . 'includes/theme-widget.php' );

/**
 * Meta box
 **/
 
load_template( trailingslashit( get_template_directory() ) . 'includes/metabox-options.php' );



 /**
 * Woocommerce template
 **/
 

if (class_exists('WooCommerce')) {
	require_once ( get_template_directory() .'/woocommerce/config.php' );
	}
	

/**
 * Magee Importer
 */
 
require get_template_directory() . '/lib/importer/importer.php';


/**
 * Magee shortcodes
 */
if( ! class_exists( 'Magee_Core' ) ) 
require get_template_directory() . '/lib/magee-shortcodes-pro/Magee.php';
	


add_filter('widget_text', 'do_shortcode');


function onetone_deactivate_plugin_conditional() {
    if ( is_plugin_active('magee-shortcodes/Magee.php') ) {
    deactivate_plugins('magee-shortcodes/Magee.php');    
    }
	if ( is_plugin_active('magee-shortcodes-pro/Magee.php') ) {
    deactivate_plugins('magee-shortcodes-pro/Magee.php');    
    }
}
add_action( 'admin_init', 'onetone_deactivate_plugin_conditional' );
add_filter( 'gca_load_column_styles', '__return_false' );
/*
// Register Custom Post Type
function team_member() {

	$labels = array(
		'name'                  => _x( 'Team Members', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Team Member', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Team Members', 'text_domain' ),
		'name_admin_bar'        => __( 'Team Member', 'text_domain' ),
		'archives'              => __( 'Team Member Archives', 'text_domain' ),
		'attributes'            => __( 'Team Member Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Team Members', 'text_domain' ),
		'all_items'             => __( 'All Team Members', 'text_domain' ),
		'add_new_item'          => __( 'Add New Team Member', 'text_domain' ),
		'add_new'               => __( 'Add New Team Member', 'text_domain' ),
		'new_item'              => __( 'New Team Member', 'text_domain' ),
		'edit_item'             => __( 'Edit Team Member', 'text_domain' ),
		'update_item'           => __( 'Update Team Member', 'text_domain' ),
		'view_item'             => __( 'View Team Member', 'text_domain' ),
		'view_items'            => __( 'View Team Members', 'text_domain' ),
		'search_items'          => __( 'Search Team Member', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into Team Member', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this Team Member', 'text_domain' ),
		'items_list'            => __( 'Team Members List', 'text_domain' ),
		'items_list_navigation' => __( 'Team Members Navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter Team Members', 'text_domain' ),
	);
	$rewrite = array(
		'slug'                  => 'team-member',
		'with_front'            => true,
		'pages'                 => true,
		'feeds'                 => true,
	);
	$args = array(
		'label'                 => __( 'Team Member', 'text_domain' ),
		'description'           => __( 'JT Law Firm Team Member', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'revisions', 'custom-fields', 'page-attributes', ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
		'show_in_rest'          => true,
		'rest_base'             => 'team_member',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
	);
	register_post_type( 'team_member', $args );

}
add_action( 'init', 'team_member', 0 );

// Register Custom Post Type
function practice_areas() {

	$labels = array(
		'name'                  => _x( 'Practice Areas', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Practice Area', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Practice Areas', 'text_domain' ),
		'name_admin_bar'        => __( 'Practice Area', 'text_domain' ),
		'archives'              => __( 'Practice Area Archives', 'text_domain' ),
		'attributes'            => __( 'Practice Area Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Practice Areas', 'text_domain' ),
		'all_items'             => __( 'All Practice Areas', 'text_domain' ),
		'add_new_item'          => __( 'Add New Practice Area', 'text_domain' ),
		'add_new'               => __( 'Add New', 'text_domain' ),
		'new_item'              => __( 'New Practice Area', 'text_domain' ),
		'edit_item'             => __( 'Edit Practice Area', 'text_domain' ),
		'update_item'           => __( 'Update Practice Area', 'text_domain' ),
		'view_item'             => __( 'View Practice Area', 'text_domain' ),
		'view_items'            => __( 'View Practice Areas', 'text_domain' ),
		'search_items'          => __( 'Search Practice Area', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into Practice Area', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this Practice Area', 'text_domain' ),
		'items_list'            => __( 'Practice Areas list', 'text_domain' ),
		'items_list_navigation' => __( 'Practice Areas list navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter Practice Areas list', 'text_domain' ),
	);
	$rewrite = array(
		'slug'                  => 'practice-area',
		'with_front'            => true,
		'pages'                 => true,
		'feeds'                 => true,
	);
	$args = array(
		'label'                 => __( 'Practice Area', 'text_domain' ),
		'description'           => __( 'JT Law Firm Practice Areas', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => true,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'page',
	);
	register_post_type( 'practice_area', $args );

}
add_action( 'init', 'practice_areas', 0 ); */

/** add_shortcode('wpbsearch', 'get_search_form');
